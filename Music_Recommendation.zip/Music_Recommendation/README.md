 Music Recommendation

Aim: 
1) Generate music recommender system using a dataset of name, artist, and lyrics for 57650 songs in English obtained from Kaggle. 

This repo is divided into the following two packages that contains the following files:  
  
I. **Content-based recommendation system**:  
   
  a. A jupyter notebook named `Music Recommendation` that contains the code and analysis for the recommedation system.  
  b. A `CSV` file named `songdataset` containing the data for the songs used in the system.

